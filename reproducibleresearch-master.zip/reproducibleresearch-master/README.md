# Reproducible Research
Author: Aditya Vikram Dash <br />

## Projects 
Project # | Markdown | R Markdown
--- | --- | ---
1 |  [Reproducible Research Project 1 (.md)](https://github.com/DeftPenk/reproducibleresearch/blob/master/Project1/PA1_template.md) | [Reproducible Research Project 1 (.Rmd)](https://github.com/DeftPenk/reproducibleresearch/blob/master/Project1/PA1_template.Rmd)
